const fs = require('fs');
const path = require('path');
const { createHash } = require('crypto');

function sha256(data) {
  const hash = createHash('sha256');
  if (Buffer.isBuffer(data)) {
    hash.update(data);
  } else {
    hash.update(data, 'utf8');
  }
  return hash.digest('hex');
}

function canonicalStringifyV2_7_0(obj) {
  const parts = [
    `"verifrax_version":${JSON.stringify(obj.verifrax_version)}`,
    `"certificate_version":${JSON.stringify(obj.certificate_version)}`,
    `"bundle_hash":${JSON.stringify(obj.bundle_hash)}`,
    `"profile_id":${JSON.stringify(obj.profile_id)}`,
    `"verdict":${JSON.stringify(obj.verdict)}`,
    `"reason_codes":${JSON.stringify(obj.reason_codes)}`,
    `"executed_at":${JSON.stringify(obj.executed_at)}`
  ];
  return `{${parts.join(',')}}`;
}

function canonicalStringifyProfile(obj) {
  if (obj === null) return 'null';
  if (Array.isArray(obj)) {
    const elements = obj.map(canonicalStringifyProfile);
    return `[${elements.join(',')}]`;
  }
  if (obj && typeof obj === 'object') {
    const keys = Object.keys(obj).sort();
    const pairs = keys.map(key => {
      const value = canonicalStringifyProfile(obj[key]);
      return `"${key}":${value}`;
    });
    return `{${pairs.join(',')}}`;
  }
  return JSON.stringify(obj);
}

function loadProfileHashes() {
  const hashesPath = path.join(__dirname, '..', '..', 'freeze', 'v2.7.0', 'PROFILE_HASHES.txt');
  
  if (!fs.existsSync(hashesPath)) {
    throw new Error('PROFILE_HASHES.txt not found');
  }
  
  const hashesData = fs.readFileSync(hashesPath, 'utf8');
  const hashes = {};
  
  for (const line of hashesData.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    
    const parts = trimmed.split(/\s+/);
    if (parts.length >= 2) {
      const hash = parts[0];
      const filename = parts[1];
      hashes[filename] = hash;
    }
  }
  
  return hashes;
}

function loadProfile(profileId) {
  const profilePath = path.join(__dirname, '..', 'profiles', `${profileId}.json`);
  
  if (!fs.existsSync(profilePath)) {
    throw new Error(`Profile not found: ${profileId}`);
  }
  
  const profileData = fs.readFileSync(profilePath, 'utf8');
  const profile = JSON.parse(profileData);
  
  const canonical = canonicalStringifyProfile(profile);
  const computedHash = sha256(canonical);
  
  const publishedHashes = loadProfileHashes();
  const expectedHash = publishedHashes[`${profileId}.json`];
  
  if (!expectedHash) {
    throw new Error(`Profile hash not found in PROFILE_HASHES.txt: ${profileId}`);
  }
  
  if (computedHash !== expectedHash) {
    throw new Error(`Profile hash mismatch for ${profileId}. Expected: ${expectedHash}, Computed: ${computedHash}. Profile may be corrupted or tampered.`);
  }
  
  return profile;
}

function executeVerificationRules(bundleData, profile) {
  const reasonCodes = [];
  
  if (!profile.verification_rules || !Array.isArray(profile.verification_rules)) {
    throw new Error('Profile missing verification_rules array');
  }
  
  for (const rule of profile.verification_rules) {
    if (!rule.check) {
      throw new Error('Verification rule missing check field');
    }
    
    if (!rule.failure_reason) {
      throw new Error('Verification rule missing failure_reason field');
    }
    
    let checkPassed = false;
    
    switch (rule.check) {
      case 'bundle_non_empty':
        checkPassed = bundleData.length > 0;
        break;
        
      case 'bundle_size_limit':
        if (typeof rule.max_size_bytes !== 'number') {
          throw new Error('bundle_size_limit rule missing max_size_bytes');
        }
        checkPassed = bundleData.length <= rule.max_size_bytes;
        break;
        
      default:
        throw new Error(`Unknown verification check: ${rule.check}`);
    }
    
    if (!checkPassed) {
      reasonCodes.push(rule.failure_reason);
    }
  }
  
  if (reasonCodes.length === 0) {
    return {
      verdict: 'verified',
      reasonCodes: []
    };
  } else {
    return {
      verdict: 'not_verified',
      reasonCodes
    };
  }
}

function verifyCertificateV2_7_0(options) {
  const { bundlePath, certificatePath, profileId } = options;

  if (!bundlePath || !certificatePath || !profileId) {
    return {
      status: 'INVALID',
      reason: 'MISSING_INPUTS'
    };
  }

  if (!fs.existsSync(bundlePath)) {
    return {
      status: 'INVALID',
      reason: 'BUNDLE_NOT_FOUND'
    };
  }

  if (!fs.existsSync(certificatePath)) {
    return {
      status: 'INVALID',
      reason: 'CERTIFICATE_NOT_FOUND'
    };
  }

  try {
    const certificateData = fs.readFileSync(certificatePath, 'utf8');
    const certificate = JSON.parse(certificateData);

    const requiredFields = [
      'verifrax_version',
      'certificate_version',
      'bundle_hash',
      'profile_id',
      'verdict',
      'reason_codes',
      'executed_at',
      'certificate_hash'
    ];

    for (const field of requiredFields) {
      if (!(field in certificate)) {
        return {
          status: 'INVALID',
          reason: 'MISSING_FIELD',
          field
        };
      }
    }

    const expectedCertificateHash = certificate.certificate_hash;

    const certificateWithoutHash = {
      verifrax_version: certificate.verifrax_version,
      certificate_version: certificate.certificate_version,
      bundle_hash: certificate.bundle_hash,
      profile_id: certificate.profile_id,
      verdict: certificate.verdict,
      reason_codes: certificate.reason_codes,
      executed_at: certificate.executed_at
    };

    const canonical = canonicalStringifyV2_7_0(certificateWithoutHash);
    const computedCertificateHash = sha256(canonical);

    if (computedCertificateHash !== expectedCertificateHash) {
      return {
        status: 'INVALID',
        reason: 'CERTIFICATE_HASH_MISMATCH'
      };
    }

    const bundleData = fs.readFileSync(bundlePath);
    const computedBundleHash = sha256(bundleData);

    if (computedBundleHash !== certificate.bundle_hash) {
      return {
        status: 'INVALID',
        reason: 'BUNDLE_HASH_MISMATCH'
      };
    }

    if (certificate.profile_id !== profileId) {
      return {
        status: 'INVALID',
        reason: 'PROFILE_ID_MISMATCH'
      };
    }

    try {
      loadProfile(profileId);
    } catch (error) {
      return {
        status: 'INVALID',
        reason: 'PROFILE_HASH_MISMATCH',
        message: error.message
      };
    }

    const profile = loadProfile(profileId);
    const verificationResult = executeVerificationRules(bundleData, profile);
    
    if (verificationResult.verdict !== certificate.verdict) {
      return {
        status: 'INVALID',
        reason: 'VERDICT_MISMATCH',
        computed_verdict: verificationResult.verdict,
        certificate_verdict: certificate.verdict
      };
    }
    
    const computedCodes = JSON.stringify(verificationResult.reasonCodes.sort());
    const certificateCodes = JSON.stringify(certificate.reason_codes.sort());
    if (computedCodes !== certificateCodes) {
      return {
        status: 'INVALID',
        reason: 'REASON_CODES_MISMATCH',
        computed_reason_codes: verificationResult.reasonCodes,
        certificate_reason_codes: certificate.reason_codes
      };
    }
    
    return {
      status: 'VALID'
    };

  } catch (error) {
    return {
      status: 'INVALID',
      reason: 'VERIFICATION_ERROR',
      message: error.message
    };
  }
}

module.exports = { verifyCertificateV2_7_0 };

