# VERIFRAX Specification v2.7.0

**Version:** 2.7.0  
**Status:** FINAL  
**Authority:** AUTHORITATIVE  
**Date:** 2025-01-15  
**Freeze Commit:** TBD

---

## Core Invariant

VERIFRAX v2.7.0 is a deterministic verification system that produces final, reproducible verdicts for evidence bundles. The system operates without mutable state, accounts, or sessions, ensuring that verification artifacts remain independently verifiable regardless of infrastructure availability or operational status.

All authority derives from frozen specification and cryptographic determinism. No operator discretion exists. No interpretation exists. No ambiguity exists.

---

## 1. System Identity

### 1.1 Definition

VERIFRAX v2.7.0 is a pure function that takes evidence bundle bytes and produces a certificate. The system has no side effects, no randomness, no external dependencies, no mutable state, no retries, and no discretion.

Same inputs produce same output, always.

### 1.2 Authority Scope

v2.7.0 authority applies to:
- Certificate schema
- Execution pipeline
- Profile definitions
- Reference verifier
- Canonicalization rules

### 1.3 Immutability

v2.7.0 is frozen. No modifications to v2.7.0 are permitted without a new version increment.

---

## 2. Certificate Schema

### 2.1 Schema Definition

The certificate schema is defined by the JSON Schema in `certificate_schema_v2.7.0.json`.

### 2.2 Required Fields

Certificates contain exactly eight fields in this exact order:

1. `verifrax_version` — String, VERIFRAX system version (e.g., "2.7.0")
2. `certificate_version` — String, certificate schema version (e.g., "1.0.0")
3. `bundle_hash` — String, SHA-256 hash of evidence bundle (64 hex characters, no prefix)
4. `profile_id` — String, verification profile identifier (format: `^[a-z_]+@[0-9]+\.[0-9]+\.[0-9]+$`)
5. `verdict` — String, verification result ("verified" or "not_verified")
6. `reason_codes` — Array of strings, empty if verified, non-empty if not_verified
7. `executed_at` — String, RFC3339 timestamp in UTC with millisecond precision
8. `certificate_hash` — String, SHA-256 hash of canonical certificate bytes (64 hex characters, no prefix)

### 2.3 Field Constraints

- `verifrax_version`: Non-empty string, semantic version format
- `certificate_version`: Non-empty string, semantic version format
- `bundle_hash`: Exactly 64 lowercase hexadecimal characters, no prefix
- `profile_id`: Matches pattern `^[a-z_]+@[0-9]+\.[0-9]+\.[0-9]+$`
- `verdict`: Exactly "verified" or "not_verified"
- `reason_codes`: Array of strings, order matters
- `executed_at`: RFC3339 format `YYYY-MM-DDTHH:mm:ss.sssZ`
- `certificate_hash`: Exactly 64 lowercase hexadecimal characters, no prefix

### 2.4 Additional Properties

The certificate schema prohibits additional properties. Certificates with extra fields are invalid.

---

## 3. Canonicalization Rules

### 3.1 Encoding

- Character Encoding: UTF-8
- Newlines: `\n` (LF, U+000A)
- No BOM: Files must not include UTF-8 BOM

### 3.2 Field Order

Fields must appear in this exact order:
1. `verifrax_version`
2. `certificate_version`
3. `bundle_hash`
4. `profile_id`
5. `verdict`
6. `reason_codes`
7. `executed_at`
8. `certificate_hash`

### 3.3 Serialization Rules

- No pretty-printing
- No indentation
- No trailing whitespace
- No spaces after colons or commas
- Single line output

### 3.4 Array Serialization

- Arrays are ordered (order matters)
- Elements serialized in array order
- No spaces after commas

### 3.5 String Serialization

- Use standard JSON string escaping
- No trailing whitespace
- Preserve exact character sequence

### 3.6 Number Serialization

- No leading zeros (except for decimals)
- No trailing zeros (except for decimals)
- Use standard JSON number format

### 3.7 Timestamp Format

Field: `executed_at`

- Format: RFC3339 with millisecond precision
- Timezone: UTC (always `Z` suffix)
- Pattern: `YYYY-MM-DDTHH:mm:ss.sssZ`
- Example: `2025-01-15T12:00:00.000Z`

Rules:
- Year: 4 digits
- Month: 2 digits (01-12)
- Day: 2 digits (01-31)
- Hour: 2 digits (00-23)
- Minute: 2 digits (00-59)
- Second: 2 digits (00-59)
- Millisecond: 3 digits (000-999)
- Always UTC (`Z`)

### 3.8 Hash Format

Fields: `bundle_hash`, `certificate_hash`

- Algorithm: SHA-256
- Encoding: Hexadecimal (lowercase)
- Length: 64 characters
- No Prefix: Do not include `sha256:` or any other prefix
- Example: `ba18a51f06af90c110924fc4e87a64dba5127bc092a582b33a2f1b844835413b`

### 3.9 Certificate Hash Computation

The `certificate_hash` field is computed after serializing all other fields.

Steps:
1. Create certificate object with all fields except `certificate_hash`
2. Serialize to canonical JSON string (following all rules above)
3. Compute SHA-256 hash of the UTF-8 encoded string
4. Encode hash as 64-character lowercase hexadecimal string
5. Add `certificate_hash` field as the final field

Formula:
```
certificate_hash = SHA-256(UTF-8(canonical_json_string))
```

Where `canonical_json_string` is the serialized certificate without the `certificate_hash` field.

### 3.10 Verification

Two independent parties serializing the same certificate inputs must produce:
1. Identical JSON bytes (not just equivalent structure)
2. Identical certificate_hash (when computed from those bytes)

---

## 4. Execution Pipeline

### 4.1 Pipeline Overview

The execution pipeline is a pure function that takes evidence bundle bytes and produces a certificate. It has no side effects, no randomness, no external dependencies, no mutable state, no retries, and no discretion.

Same inputs produce same output, always.

### 4.2 Required Inputs

1. Evidence Bundle (`bundle.bin`)
   - Binary file containing evidence to be verified
   - Format: opaque binary (no structure assumed)
   - Size: arbitrary (subject to implementation limits)

2. Profile Identifier (`profile_id`)
   - String format: `^[a-z_]+@[0-9]+\.[0-9]+\.[0-9]+$`
   - Example: `public@1.0.0`
   - Defines the deterministic verification rules

3. VERIFRAX Version (`verifrax_version`)
   - String format: semantic version
   - Example: `2.7.0`
   - Defines the execution engine version

4. Certificate Version (`certificate_version`)
   - String format: semantic version
   - Example: `1.0.0`
   - Defines the certificate schema version

### 4.3 Input Validation

- Bundle file must exist and be readable
- Profile identifier must match pattern
- Versions must be non-empty strings
- No other inputs are accepted

If validation fails, execution terminates with error (no certificate produced).

### 4.4 Bundle Hash Computation

1. Read bundle file as binary (no encoding, no interpretation)
2. Compute SHA-256 hash of raw bytes
3. Encode hash as 64-character lowercase hexadecimal string
4. No prefix (not `sha256:`, just hex)

Formula:
```
bundle_hash = SHA-256(bundle_bytes)
```

Properties:
- Deterministic: same bytes produce same hash
- One-way: hash cannot reveal original bytes
- Collision-resistant: different bytes produce different hash (with high probability)

### 4.5 Profile-Based Verification

The profile identifier determines which verification rules to apply.

Profile Loading:
1. Resolve `profile_id` to profile file
2. Read profile JSON
3. Parse JSON (no interpretation)
4. Compute hash of loaded profile
5. Compare with published hash
6. If mismatch, error (profile is corrupted or tampered)

Verification Rules:
- Execute checks in profile-defined order
- Collect reason codes (if any)
- Derive verdict

No shortcuts. No caching. No early exits (except errors).

### 4.6 Verdict Derivation

Verdict Values:
- `"verified"` — All checks passed
- `"not_verified"` — One or more checks failed

Reason Codes:
- Array of strings
- Empty array `[]` if verdict is `"verified"`
- Non-empty array if verdict is `"not_verified"`
- Order matters (codes appear in execution order)

Verdict Logic:
```
if (all_checks_passed) {
  verdict = "verified"
  reason_codes = []
} else {
  verdict = "not_verified"
  reason_codes = [collected_reason_codes]
}
```

No ambiguity. No interpretation. No discretion.

### 4.7 Certificate Construction

Build certificate object with these fields in exact order:
1. `verifrax_version` — From input
2. `certificate_version` — From input
3. `bundle_hash` — Computed from bundle bytes
4. `profile_id` — From input
5. `verdict` — Derived from verification
6. `reason_codes` — Collected from verification
7. `executed_at` — Current timestamp (RFC3339, UTC, millisecond precision)

Do not include `certificate_hash` yet.

Timestamp Generation:
- Format: RFC3339 with millisecond precision
- Timezone: UTC (always `Z` suffix)
- Pattern: `YYYY-MM-DDTHH:mm:ss.sssZ`
- Example: `2025-01-15T12:00:00.000Z`

Note: Timestamp is the only non-deterministic field. It records when execution occurred, but does not affect verification determinism.

Canonical Serialization:
1. Serialize certificate object (without `certificate_hash`) to canonical JSON
2. Follow canonicalization rules:
   - UTF-8 encoding
   - No pretty-printing
   - No trailing whitespace
   - Fields in exact order
   - No spaces after colons or commas

Formula:
```
canonical_json = canonical_stringify(certificate_object_without_hash)
```

Certificate Hash Computation:
1. Compute SHA-256 hash of canonical JSON string (UTF-8 encoded)
2. Encode as 64-character lowercase hexadecimal string
3. No prefix

Formula:
```
certificate_hash = SHA-256(UTF-8(canonical_json))
```

Final Certificate:
Add `certificate_hash` as the final field:
```
certificate = {
  ...certificate_object_without_hash,
  certificate_hash: computed_hash
}
```

Final Serialization:
Serialize final certificate to canonical JSON (following same rules).

This is the certificate that is emitted.

### 4.8 Finality Rules

One Execution, One Certificate:
- Each execution produces exactly one certificate
- No retries
- No revisions
- No amendments
- No supersession

Immutability:
- Certificate cannot be modified after emission
- Certificate hash is cryptographically bound to contents
- Any modification invalidates the certificate

Irreversibility:
- Execution cannot be undone
- Certificate cannot be revoked
- Verdict cannot be changed

Independence:
- Certificate validity does not depend on:
  - Infrastructure availability
  - Operator status
  - Payment status
  - External services
  - Network connectivity

Survivability:
- Certificate remains valid even if:
  - VERIFRAX infrastructure is destroyed
  - VERIFRAX operator disappears
  - Domain expires
  - Service shuts down

### 4.9 Execution Guarantees

Determinism:
For identical:
- Bundle bytes
- Profile identifier
- VERIFRAX version

The execution must produce:
- Identical `bundle_hash`
- Identical `verdict`
- Identical `reason_codes`
- Identical `certificate_hash`

Only `executed_at` may differ (timestamp).

Completeness:
- Every execution produces a certificate
- Every certificate is complete (all 8 fields)
- Every certificate is valid (hash matches)

Finality:
- Execution is final upon certificate emission
- No post-execution modifications
- No dispute resolution
- No appeals

### 4.10 Error Handling

Input Errors:
- Invalid bundle → execution terminates (no certificate)
- Invalid profile → execution terminates (no certificate)
- Missing inputs → execution terminates (no certificate)

Execution Errors:
- Profile load failure → execution terminates (no certificate)
- Verification logic error → execution terminates (no certificate)
- Serialization error → execution terminates (no certificate)

No Partial Certificates:
- Either a complete certificate is produced, or no certificate is produced
- No "pending" state
- No "incomplete" certificates
- No retry mechanisms

### 4.11 Pipeline Summary

```
Inputs (bundle, profile, versions)
  ↓
Bundle Hash Computation
  ↓
Profile-Based Verification
  ↓
Verdict Derivation
  ↓
Certificate Construction (without hash)
  ↓
Canonical Serialization
  ↓
Certificate Hash Computation
  ↓
Final Certificate (with hash)
  ↓
Certificate Emission
```

One path. No branches (except errors). No loops. No retries.

---

## 5. Profile Authority

### 5.1 Definition

A profile is a frozen, versioned, immutable specification that defines:
- What constitutes "verified" for a given evidence bundle
- What constitutes "not_verified" for a given evidence bundle
- What reason codes to emit for each failure mode
- What verification checks to execute (in order)
- What bundle constraints apply (size, structure, content)

### 5.2 Profile Identity

A profile is identified by a profile identifier:
- Format: `^[a-z_]+@[0-9]+\.[0-9]+\.[0-9]+$`
- Example: `public@1.0.0`
- Components:
  - Profile name: `public` (semantic identifier)
  - Version: `1.0.0` (semantic version)

### 5.3 Profile Structure

A profile is a JSON object with the following required fields:
- `profile_id` — The profile identifier (must match filename pattern)
- `profile_name` — The profile name component
- `version` — The version component
- `verification_rules` — Deterministic rules that define verification logic
- `reason_code_mappings` — Mapping from failure modes to reason codes
- `bundle_constraints` — Constraints on bundle structure and size

No optional fields. No interpretation. No ambiguity.

### 5.4 Version Immutability

Once a profile version is published:
- It cannot be modified
- It cannot be superseded retroactively
- It cannot be deleted
- It cannot be reinterpreted

Version immutability is absolute and permanent.

### 5.5 Cryptographic Binding

Each profile must have a cryptographic hash:
- Algorithm: SHA-256
- Encoding: 64-character lowercase hexadecimal (no prefix)
- Computed from: canonical JSON serialization of profile object

Formula:
```
profile_hash = SHA-256(UTF-8(canonical_json(profile)))
```

Canonical Serialization:
- UTF-8 encoding
- No pretty-printing
- No trailing whitespace
- Fields in deterministic order (alphabetical by key)
- Arrays in order

Same profile produces same hash, always.

### 5.6 Hash Publication

Profile hashes must be published in:
- `freeze/v2.7.0/PROFILE_HASHES.txt`
- Format: `<hash>  <profile_id>.json`
- One hash per profile version

Hash publication is the proof of immutability.

### 5.7 Profile Storage

Profiles are stored as:
- Files: `verifrax-reference-verifier/profiles/<profile_id>.json`
- Immutable: Once published, file contents never change
- Versioned: Each version is a separate file

File system is for distribution only. Hash is the authority.

### 5.8 Profile Loading Contract

Both engines and verifiers must:
1. Load profile by identifier
   - Resolve `profile_id` to profile file
   - Read profile JSON
   - Parse JSON (no interpretation)

2. Verify profile hash
   - Compute hash of loaded profile
   - Compare with published hash
   - If mismatch → error (profile is corrupted or tampered)

3. Execute against profile rules
   - Apply verification rules deterministically
   - Emit reason codes according to mappings
   - No interpretation, no discretion

### 5.9 Deterministic Execution

Profile rules must be executable deterministically:
- Same profile + same bundle → same verdict
- Same profile + same bundle → same reason codes
- No randomness
- No external dependencies
- No time-dependent logic

### 5.10 Profile Rule Format

Profile rules are defined as declarative JSON, not executable code:

```json
{
  "verification_rules": [
    {
      "check": "bundle_non_empty",
      "failure_reason": "BUNDLE_EMPTY"
    },
    {
      "check": "bundle_size_limit",
      "max_size_bytes": 1048576,
      "failure_reason": "BUNDLE_TOO_LARGE"
    }
  ],
  "reason_code_mappings": {
    "BUNDLE_EMPTY": "Bundle file is empty",
    "BUNDLE_TOO_LARGE": "Bundle exceeds size limit"
  }
}
```

Rules are data, not code. Interpretation is fixed by engine implementation.

### 5.11 Profile Dispute Prevention

Disputes about profile meaning are prevented by:
1. Immutability — Profile cannot change after publication
2. Versioning — Each version is distinct and frozen
3. Hashing — Profile integrity is cryptographically verifiable
4. Determinism — Profile rules are applied deterministically
5. Explicitness — Profile rules are declarative, not interpretive

No interpretation disputes exist because interpretation is fixed.
No version disputes exist because versions are immutable and distinct.
No authority disputes exist because authority is structural.

---

## 6. Reference Verifier

### 6.1 Purpose

The reference verifier enables third-party validation without VERIFRAX infrastructure. It is an offline verifier that can verify certificates independently.

### 6.2 Verification Steps

Verification steps (order is law):
1. Read certificate bytes as-is
2. Recompute certificate_hash from canonical rules
3. Recompute bundle_hash from bundle bytes
4. Check profile_id equality
5. Verify profile hash
6. Re-run deterministic verification logic
7. If all match → VALID

### 6.3 Independence

The reference verifier:
- Requires no network calls
- Requires no VERIFRAX infrastructure
- Requires no operator presence
- Requires no payment
- Requires no external services

### 6.4 Authority

If engine and verifier disagree, the verifier is authoritative.

---

## 7. Implementation Requirements

### 7.1 Pure Function

The execution pipeline must be implementable as a pure function:
- Deterministic execution
- No side effects
- No external calls
- Returns complete certificate

### 7.2 Local Execution

The pipeline must be executable:
- Locally (no network)
- Offline (no external services)
- Independently (no VERIFRAX infrastructure)

### 7.3 Reproducibility

The pipeline must be reproducible:
- Same inputs → same outputs
- Different machines → same results
- Different times → same results (except timestamp)

---

## 8. What Certificates Do Not Assert

Certificates do not assert:
- Legal validity of claims
- Truth of claims
- Enforceability of claims
- Acceptance of claims
- Obligation to act on claims
- Compliance with regulations
- Endorsement by VERIFRAX
- Trust in claims or evidence

Certificates only assert:
- Deterministic verification execution
- Cryptographic integrity
- Profile compliance
- Immutable record

---

## 9. Version Policy

v2.7.0 is frozen. No retroactive changes to verification logic. No changes to certificate format. No changes to finality semantics. Authority derives solely from frozen specification and cryptographic determinism.

Any future change requires v2.8.0.

---

**END OF VERIFRAX v2.7.0 SPECIFICATION**

