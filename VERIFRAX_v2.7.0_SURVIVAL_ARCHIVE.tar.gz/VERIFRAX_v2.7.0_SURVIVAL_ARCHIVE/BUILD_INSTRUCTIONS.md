# VERIFRAX v2.7.0 — BUILD INSTRUCTIONS

Target: verifrax execution engine v2.7.0

## Environment

- OS: macOS 14.x or Linux x86_64
- Node.js: v20.11.0
- npm: v10.x
- OpenSSL: 3.x

## Build Steps

1. Install dependencies:
   npm install

2. No transpilation, bundling, or minification permitted.

3. The executable authority file is:
   execute_v2_7_0.js

4. Hash verification:
   shasum -a 256 execute_v2_7_0.js

The resulting hash must match BUILD_HASH.txt.

Any deviation invalidates the build.

