# VERIFRAX v2.7.0 — Survival Archive

This archive contains everything required to verify VERIFRAX v2.7.0 certificates without network access, infrastructure, or operator.

## Verification Requirements

- Node.js v20.11.0 or later
- SHA-256 support (built into Node.js)
- This archive only

## Authority

Authority is defined by `SYSTEM_IDENTITY.json`.

System Identity Digest (SID): `1f9b7dd031ec16e241a84bf7bae90bfa5444d2b39b93ac45013b25e5aba56504`

## Contents

- `SPEC_VERIFRAX_v2.7.0.md` — Complete specification
- `FREEZE_COMMIT_v2.7.0.txt` — Freeze authority declaration
- `SYSTEM_IDENTITY.json` — System Identity Digest
- `certificate_schema_v2.7.0.json` — Certificate schema
- `BUILD_INSTRUCTIONS.md` — Build instructions
- `BUILD_ENVIRONMENT.json` — Build environment
- `BUILD_HASH.txt` — Engine executable hash
- `execute_v2_7_0.js` — Execution engine
- `verify_v2_7_0.js` — Reference verifier
- `profiles/` — Verification profiles
- `PROFILE_HASHES.txt` — Profile cryptographic hashes

## Usage

### Verify a Certificate

```bash
node verify_v2_7_0.js \
  --bundle <bundle.bin> \
  --certificate <certificate.json> \
  --profile public@1.0.0
```

### Execute Verification (Re-run)

```bash
node execute_v2_7_0.js \
  --bundle <bundle.bin> \
  --profile public@1.0.0 \
  --output certificate.json
```

## Independence

This archive enables:
- Offline verification (no network required)
- Post-operator verification (no infrastructure required)
- Independent verification (no VERIFRAX dependency)
- Permanent verification (hashes sufficient forever)

## Hash Verification

All artifacts are cryptographically hashed. Verify hashes match published values before use.

---

**END OF SURVIVAL ARCHIVE README**

